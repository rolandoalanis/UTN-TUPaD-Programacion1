nombre_gladiador = input("Ingrese el nombre del gladiador: ").strip() # Quita espacios del principio y final

while not nombre_gladiador.isalpha():
    print("Error, solo se permiten letras")
    nombre_gladiador = input("Ingrese el nombre del gladiador: ").strip() # Quita espacios del principio y final

nombre_gladiador = nombre_gladiador.capitalize() 

vida_gladiador = 100  
vida_enemigo = 100 
pociones_vida = 3
danio_base_gladiador = 15
danio_base_enemigo = 12
turno_gladiador = True

while vida_gladiador > 0 and vida_enemigo > 0:
    if turno_gladiador:
        print(f"La vida del gladiador {nombre_gladiador} es {vida_gladiador}")
        print(f"la vida del enemigo es {vida_enemigo}")
        print(f"Te quedan {pociones_vida} pociones de vida")
        print()

        while True:
            opcion = input("Ingrese una acción:\n1. Ataque pesado\n2. Ataque por ráfaga\n3.Curar\n").strip()

            while not opcion.isdigit():
                print("Error, solo se permiten números")
                opcion = input("Ingrese una acción:\n1. Ataque pesado\n2. Ataque por ráfaga\n3.Curar\n").strip()
            
            opcion = int(opcion)
            match opcion:
                case 1:
                    danio_final = 0
                    if vida_enemigo < 20:
                        danio_final = 1.5 * danio_base_gladiador
                    else:
                        danio_final = danio_base_gladiador
                    vida_enemigo = vida_enemigo - danio_final
                    print(f"Atacaste al enemigo por {danio_final} puntos de daño ")
                    turno_gladiador = False # Esto es para que no vuelva al ciclo de arriba y sea turno del enemigo (al else)
                    break # Sí o sí tiene que ir porque el while es siempre True
                case 2:
                    for _ in range(3): # Coloco el guión bajo porque no necesito trabajar con la variable
                        vida_enemigo -= 5 
                        print("Golpe conectado por 5 de daño")
                    turno_gladiador = False
                    break
                case 3:
                    if pociones_vida > 0:
                        vida_gladiador += 30
                        pociones_vida -= 1
                    else:
                        print("No te quedan pociones! ")
                        print("Perdiste el turno")
                        turno_gladiador = False
                    break
                case _:
                    print("El número ingresado no es válido") 
    else:
        vida_gladiador = vida_gladiador - danio_base_enemigo
        print("El enemigo te hizo un daño de 12 puntos")
        turno_gladiador = True

if vida_gladiador > 0:
    print(f"Victoria !! {nombre_gladiador} ha ganado la batalla")
else:
    print("Derrota. Ha caído en combate")

