# 1_ Pedir nombre del cliente (solo letras, validar con .isalpha() en while)
# 2_ Pedir cantidad de productos a comprar (número entero positivo, validar con.isdigit() en while).
# 3_ Por cada producto (usar for):
#       Pedir precio (entero, validar .isdigit()).
#       Pedir si tiene descuento S/N (validar con while, aceptar s o n en cualquier mayuscula/minuscula).
#       Si tiene descuento: aplicar 10% al precio de ese producto.
# 4_ Al final mostrar:
#       Total sin descuentos
#       Total con descuentos
#       Ahorro total
#       Promedio por producto (usar float y formatear con :.2f, ejem:
# x = 3.14159
# print(f"{x:.2f}"))

nombre = input("Cliente: ").strip() # quita espacios

while nombre == "" or not nombre.isalpha(): # Que no esté vacío y solo sean letras
    print("Error, ingrese el nombre que solo sean letras y sin espacios vacíos")
    nombre = input("Cliente: ").strip()

cantidad_str = input("Ingrese la cantidad de productos: ").strip() # Quita espacios

while not cantidad_str.isdigit() or int(cantidad_str) == 0: # Valido que sea dígito del 1 al 9
    print("Ingrese un número entero mayor al cero(0):")
    cantidad_str = input("Ingrese la cantidad de productos: ").strip() # Quita espacios

cant_int = int(cantidad_str) # Lo convierto ahora a entero una vez vaalidado

# Defino variables total_con_descento y toal_sin_descuento
total_sin_descuento = 0
total_con_descuento = 0

for i in range(1, cant_int + 1):
    precio_str = input(f"Producto {i} - Precio: ").strip()

    while not precio_str.isdigit() or int(precio_str) <= 0:
        print("Error, el precio debe ser un entero positivo")
        precio_str = input(f"Producto {i} - Precio: ").strip()
    
    #Convertir a in una vez validado
    precio_int = int(precio_str)

    # Preguntamos si aplica descuento
    desc = input("Descuento (S/N): ").strip().lower()

    # Valido que solo sea s o n
    while desc != "s" and desc != "n":
        print("Error, Ingrese S para si o N para no")
        desc = input("Descuento (S/N): ").strip().lower()
    
    # Sumatoria de los precios sin descuento
    total_sin_descuento += precio_int

    if desc == "s":
        precio_final = precio_int * 0.9
    else:
        precio_final = precio_int
    
    total_con_descuento = precio_final

    print(f"Producto {i} - Precio: ${precio_final}")

ahorro = total_con_descuento - total_sin_descuento
promedio = total_con_descuento / cant_int

print() # Sollo para salto de línea
print(f"Total sin descuento: {total_sin_descuento:.2f}")
print(f"Total con descuento: {total_con_descuento:.2f}")
print("El ahorro total es: ", ahorro)
print(f"Promedio por producto: {promedio}")