# Variables iniciales del juego
energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
racha_forzar = 0  # Contador para la regla anti-spam

# Validación del nombre del agente
nombre_agente = input("Nombre del agente: ")
while not nombre_agente.isalpha() or nombre_agente == "":
    nombre_agente = input("Error: Ingrese un nombre válido (solo letras): ")

# Bucle principal del juego
while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and not (alarma and tiempo <= 3):
    print(f"\n--- ESTADO DEL AGENTE: {nombre_agente} ---")
    print(f"Energía: {energia} | Tiempo: {tiempo} | Cerraduras: {cerraduras_abiertas}/3")
    print(f"Alarma: {'ACTIVADA' if alarma else 'DESACTIVADA'} | Código: {codigo_parcial}")
    
    print("\nMenú de acciones:")
    print("1. Forzar cerradura (Costo: -20 energía, -2 tiempo)")
    print("2. Hackear panel (Costo: -10 energía, -3 tiempo)")
    print("3. Descansar (Costo: +15 energía, -1 tiempo)")
    
    opcion = input("Elija una opción: ")
    while not opcion.isdigit() or (opcion != "1" and opcion != "2" and opcion != "3"):
        opcion = input("Error: Ingrese 1, 2 o 3: ")

    if opcion == "1":
        racha_forzar += 1
        energia -= 20
        tiempo -= 2
        
        # Regla anti-spam: 3 veces seguidas activa alarma y no abre
        if racha_forzar >= 3:
            alarma = True
            print("¡La cerradura se trabó por forzarla demasiado! ALARMA ACTIVADA.")
        else:
            # Riesgo de alarma si la energía es baja
            if energia < 40:
                print("¡CUIDADO! Energía baja, riesgo de activar alarma.")
                n_riesgo = input("Elija un número del 1 al 3: ")
                while not n_riesgo.isdigit() or n_riesgo not in ["1", "2", "3"]:
                    n_riesgo = input("Ingrese un número válido (1-3): ")
                if n_riesgo == "3":
                    alarma = True
                    print("¡Movimiento torpe! Has activado la alarma.")
            
            if not alarma:
                cerraduras_abiertas += 1
                print("¡Lograste abrir una cerradura!")

    elif opcion == "2":
        racha_forzar = 0  # Se corta la racha de forzar
        energia -= 10
        tiempo -= 3
        print("Iniciando hackeo de panel...")
        for i in range(1, 5):
            print(f"Procesando fragmento {i}...")
            codigo_parcial += "A"
        
        # Si el código llega a 8 letras, abre una cerradura automáticamente
        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas += 1
            print("¡Código descifrado! Una cerradura se abrió automáticamente.")

    elif opcion == "3":
        racha_forzar = 0
        recuperacion = 15
        if alarma:
            recuperacion -= 10  # Penalización por alarma encendida
        
        energia += recuperacion
        if energia > 100:
            energia = 100
        tiempo -= 1
        print(f"Has descansado. Energía recuperada: {recuperacion}.")

# Evaluación de condiciones de fin de juego
if cerraduras_abiertas == 3:
    print("\n¡VICTORIA! Has abierto la bóveda a tiempo.")
elif alarma and tiempo <= 3:
    print("\nDERROTA: El sistema se bloqueó por la alarma.")
else:
    print("\nDERROTA: Te has quedado sin energía o tiempo.")