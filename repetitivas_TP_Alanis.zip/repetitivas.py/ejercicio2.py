# Ejercicio 2 — “Acceso al Campus y Menú Seguro”
# Objetivo: Login con intentos + menú de acciones con validación estricta
# 1. Definir credenciales fijas en el código:
#   usuario correcto: "alumno"
#   clave correcta: "python123"
# 2. Permitir máximo 3 intentos para ingresar usuario y clave.
# 3. Si falla 3 veces: mostrar “Cuenta bloqueada” y terminar.
# 4. Si ingresa bien: mostrar un menú repetitivo (usar while) hasta elegir salir:
#   1. Ver estado de inscripción (mostrar “Inscripto”)
#   2. Cambiar clave (pedir nueva clave y confirmación; deben coincidir)
#   3. Mostrar mensaje motivacional (1 frase)
#   4. Salir
# 5. Validación del menú:
#   Debe ser número (.isdigit())
#   Debe estar entre 1 y 4
# Cambio de clave
# • La nueva clave debe tener mínimo 6 caracteres (validar con len()), si no, rechazar

# Defino Credenciales
usuario_correcto= "alumno"
clave_correcta = "python123"

intentos = 0 # Creo contador para permitir 3 intentos

while intentos < 3:
    usuario = (input("Ingrese nombre de usuario: "))
    clave = (input("Ingrese contraseña: "))

    if usuario == usuario_correcto.strip().lower() and clave == clave_correcta:
        print("Acceso al menú")
        break
    else:
        intentos += 1
        print(f"Datos icorrectos, Intento {intentos} de 3")
else:
    print("Ha superado los 3 intentos - Cuenta bloqueada")
    exit() 
    
# Ingreso al MENU
while True:
    print("----- MENU PRINCIPAL ------")
    print("1. Ver estado de incscripción: ")
    print("2. Cambiar Clave")
    print("3. Mensaje Motivacional")
    print("4. Salir ")

    opcion = input("Elije la opción del 1 al 4: ")

    if not opcion.isdigit():
        print("Elige un número: ")
        continue

    opcion = int(opcion) # Valido una vez que elije
    if opcion < 1 or opcion > 4:
        print("Debes ingresar un número del 1 al 4")
        continue
    
    # Uso de match para las opciones
    match opcion:
        case 1:
            print("Estás Inscripto")
        case 2:
            nueva_clave = input("Nueva clave: ")
            confirmar_clave = input("Confirmar clave: ")
            if len(nueva_clave) < 6:
                print("La clave debe tener al menos 6 caracteres")
            elif nueva_clave != confirmar_clave:
                print("Las claves no coinciden.")
            else:
                clave_correcta = nueva_clave
                print("Clave cambiada con éxito.")
        case 3:
            print("El que abandona no tiene premio!")
        case 4:
            print("Saliendo")
            break

