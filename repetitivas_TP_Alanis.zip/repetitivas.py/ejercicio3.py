# Ejercicio 3 (Alta) — “Agenda de Turnos con Nombres (sin listas)”
# Contexto
# Hay 2 días de atención: Lunes y Martes.
# Cada día tiene cupos fijos:
# • Lunes: 4 turnos
# • Martes: 3 turnos
# Reglas
# 1. Pedir nombre del operador (solo letras).

# 2. Menú repetitivo hasta salir:
#   1. Reservar turno
#   2. Cancelar turno (por nombre)
#   3. Ver agenda del día
#   4. Ver resumen general
#   5. Cerrar sistema

# 3. Reservar:
#   Elegir día (1=Lunes, 2=Martes).
#   Pedir nombre del paciente (solo letras).
#   Verificar que no esté repetido en ese día (comparando con las variables ya cargadas).
#   Guardar en el primer espacio libre (ej. lunes1, lunes2…).

# 4. Cancelar:
#   Elegir día.
#   Pedir nombre del paciente (solo letras).
#   Si existe, cancelar y dejar el espacio vacío ("").

# 5. Ver agenda del día:
#   Mostrar los turnos del día en orden (Turno 1..N), indicando “(libre)” si está vacío.
# 6. Resumen general:
#   Turnos ocupados y disponibles por día.
#   Día con más turnos (o empate).

lunes1 = ""
lunes2 = ""
lunes3 = ""
lunes4 = ""
martes1 = "" 
martes2 = ""
martes3 = ""

nombre = input("Ingrese su nombre: ").strip() # Pedir nombre del operador (solo letras)

while nombre == "" or not nombre.isalpha():
    print("Por favor ingrese solo letras sin espacio")
    nombre = input("Ingrese su nombre: ").strip()

opcion = ""

while opcion != "5":
    print(f"\n--- Agenda de {nombre} ---")
    print("1. Reservar turno\n2. Cancelar turno\n3. Ver agenda\n4. Resumen\n5. Cerrar")
    opcion = input("Opción: ")

    if opcion == "1":  # Reserva de turno
        dia = input("Día (1=Lunes, 2=Martes): ")
        while dia != "1" and dia != "2":
            dia = input("Por favor, ingrese 1 o 2: ")
        
        paciente = input("Ingrese el nombre del paciente: ")
        while not paciente.isalpha() or paciente == "":
            paciente = input("Por favor, ingrese 1 o 2: ")

        # Verificar que no esté repetido en ese día 
        if dia == "1":
            if paciente == lunes1 or paciente == lunes2 or paciente == lunes3 or paciente== lunes4:
                print("Error: El paciente ya tiene turno.")
            elif lunes1 == "": 
                lunes1 = paciente
            elif lunes2 == "": 
                lunes2 = paciente
            elif lunes3 == "": 
                lunes3 = paciente
            elif lunes4 == "": 
                lunes4 = paciente
            else: 
                print("Lunes sin cupos.")
        else:
            if paciente == martes1 or paciente == martes2 or paciente == martes3:
                print("Error: El paciente ya tiene turno.")
            elif martes1 == "": martes1 = paciente # de esta manera mantengo todo en la misma linea y ahorro saltos de lineas
            elif martes2 == "": martes2 = paciente
            elif martes3 == "": martes3 = paciente
            else: print("Martes sin cupos.")

    elif opcion == "2":  # Opción cancelar Turno
        cancelar = input("Nombre del paciente a cancelar: ")
        if lunes1 == cancelar: lunes1 = ""
        elif lunes2 == cancelar: lunes2 = ""
        elif lunes3 == cancelar: lunes3 = ""
        elif lunes4 == cancelar: lunes4 = ""
        elif martes1 == cancelar: martes1 = ""
        elif martes2 == cancelar: martes2 = ""
        elif martes3 == cancelar: martes3 = ""
        else: print("Paciente no encontrado.")

    elif opcion == "3": # Ver agenda del día
        ver_dia = input("Día (1 o 2): ")
        if ver_dia == "1":
            t1 = lunes1 if lunes1 != "" else "(libre)" # operador ternario, if y ekse en la misma línea
            t2 = lunes2 if lunes2 != "" else "(libre)"
            t3 = lunes3 if lunes3 != "" else "(libre)"
            t4 = lunes4 if lunes4 != "" else "(libre)"
            print(f"Lunes - T1: {t1}, T2: {t2}, T3: {t3}, T4: {t4}")
        else:
    
            t1 = martes1 if martes1 != "" else "(libre)" # operador ternario, if y ekse en la misma línea
            t2 = martes2 if martes2 != "" else "(libre)"
            t3 = martes3 if martes3 != "" else "(libre)"
            print(f"Martes - T1: {t1}, T2: {t2}, T3: {t3}")
    # Resumen general
    contador_lunes = 0
    for i in range(1, 5):  # 1 a 4
        if i == 1 and lunes1 != "":
            contador_lunes += 1
        elif i == 2 and lunes2 != "":
            contador_lunes += 1
        elif i == 3 and lunes3 != "":
            contador_lunes += 1
        elif i == 4 and lunes4 != "":
            contador_lunes += 1

    contador_martes = 0
    for j in range(1, 4):  # 1 a 3
        if j == 1 and martes1 != "":
            contador_martes += 1
        elif j == 2 and martes2 != "":
            contador_martes += 1
        elif j == 3 and martes3 != "":
            contador_martes += 1

    print(f"Ocupados - Lunes: {contador_lunes}/4, Martes: {contador_martes}/3") # Turnos ocupados y disponibles por día.         
    if contador_lunes > contador_martes: #  Día con más turnos (o empate).
        print("El Lunes es el día con más turnos")
    elif contador_martes > contador_lunes:
        print("El Martes es el día con más turno")
    else:
        print("Empate de turnos en ambos días")
